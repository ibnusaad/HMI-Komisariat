<?php
	if(!defined("INDEX")) die("---");
	
	$hal 	= isset($_GET['hal']) ? $_GET['hal'] : 1;
	
	$batas	= 5; 
	$posisi = ($hal-1) * $batas ;
	
	$artikel = mysql_query("select * from islam order by id_islam desc limit $posisi, $batas");
	while($data = mysql_fetch_array($artikel)){
		$isi = substr($data['isi'],0,300);
		$isi = substr($data['isi'],0,strrpos($isi," "));
?>

	<div class="islam">
	<div class="container">
		<div class="row">
			
			<div class="col-sm-6 wowload fadeInUp"><div class="rooms">
				<br><br>
			<h3 class="judul"><?php echo $data['judul']; ?></h3>
			<?php if($data['gambar']!="") ?> <img src="gambar/islam/<?php echo $data['gambar']; ?>" class="img-responsive"><div class="info" >
			
				<?php echo $isi; ?> ... 
				<a href="?tampil=islam_detail&id=<?php echo $data['id_islam']; ?>" class="btn btn-success btn-xs">Selengkapnya</a>
			</div>
		</div>
	</div>
	<center>
<?php
	}
	
	$semua = mysql_query("select * from artikel");
	$jmldata = mysql_num_rows($semua);
	$jmlhal	 = ceil($jmldata/$batas);	
	$sebelumnya = $hal - 1;
	$berikutnya = $hal + 1;
	
	echo "<br><div class='paging'>";
	
	if($hal > 1){
		echo "<span class='btn btn-default'><a  href='?tampil=home&hal=1'> Pertama</a></span> ";
		echo "<span class='btn btn-default'><a href='?tampil=home&hal=$sebelumnya'> Sebelumnya</a></span> ";
	}else{
		echo "<span class='btn btn-success'> Pertama</span> ";
		echo "<span class='btn btn-success'> Sebelumnya</span> ";
	}
	
	for($i=1; $i<=$jmlhal; $i++){
		if($i == $hal) echo "<span class='btn btn-default'> <b>$i</b> </span> ";
		else echo "<span class='btn btn-default'><a href='?tampil=home&hal=$i'> $i </a></span> ";
	}
	
	if($hal < $jmlhal){
		echo "<span class='btn btn-default'><a href='?tampil=home&hal=$berikutnya'> Berikutnya </a></span> ";
		echo "<span class='btn btn-default'><a href='?tampil=home&hal=$jmlhal'> Terakhir </a></span> ";
	}else{
		echo "<span class='btn btn-success'> Berikutnya </span> ";
		echo "<span class='btn btn-success'> Terakhir </span> ";		
	}

	echo "</div><br>";

?></center>