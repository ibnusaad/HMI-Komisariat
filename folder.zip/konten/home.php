<?php
	if(!defined("INDEX")) die("---");
	
	include "konten/slideshow.php";


	$hal 	= isset($_GET['hal']) ? $_GET['hal'] : 1;
	
	$batas	= 4;
	$posisi = ($hal-1) * $batas ;
	
	$artikel = mysql_query("select * from artikel order by id_artikel desc limit $posisi, $batas");
	while($data = mysql_fetch_array($artikel)){
		$isi = substr($data['isi'],0,300);
		$isi = substr($data['isi'],0,strrpos($isi," "));
?>
	<div class="artikel">
	<div class="container">
	<div class="row">
		
		
		 <div class="col-sm-6 wowload fadeInUp"><div class="rooms">
		 <h3 class="judul"><?php echo $data['judul']; ?></h3>
			<?php if($data['gambar']!="") ?>  <img src="gambar/artikel/<?php echo $data['gambar']; ?>" class="img-responsive"><div class="info" >
			
				<?php echo $isi; ?> ... 
				<a href="?tampil=artikel_detail&id=<?php echo $data['id_artikel']; ?>" class="btn btn-default btn-xs">Selengkapnya</a>
			</div>
			</div>
	</div>
	<center>
<?php
	}
	
	$semua = mysql_query("select * from artikel");
	$jmldata = mysql_num_rows($semua);
	$jmlhal	 = ceil($jmldata/$batas);	
	$sebelumnya = $hal - 1;
	$berikutnya = $hal + 1;
	
	echo "<br><div class='paging'>";
	
	if($hal > 1){
		echo "<span class='btn btn-default'><a  href='?tampil=home&hal=1'> Pertama</a></span> ";
		echo "<span class='btn btn-default'><a href='?tampil=home&hal=$sebelumnya'> Sebelumnya</a></span> ";
	}else{
		echo "<span class='btn btn-success'> Pertama</span> ";
		echo "<span class='btn btn-success'> Sebelumnya</span> ";
	}
	
	for($i=1; $i<=$jmlhal; $i++){
		if($i == $hal) echo "<span class='btn btn-default'> <b>$i</b> </span> ";
		else echo "<span class='btn btn-default'><a href='?tampil=home&hal=$i'> $i </a></span> ";
	}
	
	if($hal < $jmlhal){
		echo "<span class='btn btn-default'><a href='?tampil=home&hal=$berikutnya'> Berikutnya </a></span> ";
		echo "<span class='btn btn-default'><a href='?tampil=home&hal=$jmlhal'> Terakhir </a></span> ";
	}else{
		echo "<span class='btn btn-success'> Berikutnya </span> ";
		echo "<span class='btn btn-success'> Terakhir </span> ";		
	}

	echo "</div><br>";

?></center>

<div class="spacer services wowload fadeInUp">
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <!-- RoomCarousel -->
            <div id="RoomCarousel" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
    <?php
        $artikel = mysql_query("select * from galeri order by id_galeri desc limit 4");
        $no=0;
        while($data = mysql_fetch_array($artikel)){
    ?>
        <li data-target="#mycarousel" data-slide-to="<?php echo $no; ?>"
            <?php if($no == 0) echo ' class="active"'; ?>
        > </li>
    <?php
            $no++;
        }   
    ?>
    </ol>
    
    <div class="carousel-inner">
    <?php
        $artikel = mysql_query("select * from galeri order by id_galeri desc limit 4");
        $no=0;
        while($data = mysql_fetch_array($artikel)){
          
    ?>
        <div class="item
        <?php if($no == 0) echo ' active'; ?>
        ">
            <img src="gambar/galeri/<?php echo $data['gambar']; ?>" width="100%">  
        </div>
    <?php
            $no++;
        }
    ?>
    </div>
                <a class="left carousel-control" href="#RoomCarousel" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                <a class="right carousel-control" href="#RoomCarousel" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
            </div>
            <!-- RoomCarousel-->
            <div class="caption">Galeri<a href="?tampil=galeri" class="pull-right"><i class="fa fa-edit"></i></a></div>
        </div>


        <div class="col-sm-4">
            <!-- RoomCarousel -->
            
                <div id="RoomCarousel" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
    <?php
        $artikel = mysql_query("select * from artikel order by id_artikel desc limit 4");
        $no=0;
        while($data = mysql_fetch_array($artikel)){
    ?>
        <li data-target="#mycarousel" data-slide-to="<?php echo $no; ?>"
            <?php if($no == 0) echo ' class="active"'; ?>
        > </li>
    <?php
            $no++;
        }   
    ?>
    </ol>
    
    <div class="carousel-inner">
    <?php
        $artikel = mysql_query("select * from artikel order by id_artikel desc limit 4");
        $no=0;
        while($data = mysql_fetch_array($artikel)){
          
    ?>
        <div class="item
        <?php if($no == 0) echo ' active'; ?>
        ">
            <img src="gambar/artikel/<?php echo $data['gambar']; ?>" width="100%">  
        </div>
    <?php
            $no++;
        }
    ?>
    </div>
                <!-- Controls -->
                <a class="left carousel-control" href="#TourCarousel" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                <a class="right carousel-control" href="#TourCarousel" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
            </div>
            <!-- RoomCarousel-->
            <div class="caption">Slide Artikel<a href="#" class="pull-right"><i class="fa fa-edit"></i></a></div>
        </div>


        <div class="col-sm-4">
            <div id="RoomCarousel" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
    <?php
        $artikel = mysql_query("select * from islam order by id_islam desc limit 4");
        $no=0;
        while($data = mysql_fetch_array($artikel)){
    ?>
        <li data-target="#mycarousel" data-slide-to="<?php echo $no; ?>"
            <?php if($no == 0) echo ' class="active"'; ?>
        > </li>
    <?php
            $no++;
        }   
    ?>
    </ol>
    
    <div class="carousel-inner">
    <?php
        $artikel = mysql_query("select * from islam order by id_islam desc limit 4");
        $no=0;
        while($data = mysql_fetch_array($artikel)){
          
    ?>
        <div class="item
        <?php if($no == 0) echo ' active'; ?>
        ">
            <img src="gambar/islam/<?php echo $data['gambar']; ?>" width="100%">  
        </div>
    <?php
            $no++;
        }
    ?>
    </div>
                <a class="left carousel-control" href="#FoodCarousel" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                <a class="right carousel-control" href="#FoodCarousel" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
            </div>
            <!-- RoomCarousel-->
            <div class="caption">Food and Drinks<a href="?tampil=islam" class="pull-right"><i class="fa fa-edit"></i></a></div>
        </div>
    </div>
</div>
</div>
</div>
<!-- services -->


