<?php
if(!defined("INDEX")) die ("---");
$artikel = mysql_query("select * from halaman where id_halaman='$_GET[id]'");
$data=mysql_fetch_array($artikel);
$isi = $data['isi'];
?>
<div class="col-sm-12 wowload fadeInUp">
<div class="halaman">
<div class="container">
<div class="row">

<h2 class="judul"><?php echo $data['judul']; ?></h2>
<p>
<?php echo $isi; ?>
</p>
</div>