 <html>
<title>Download</title>
<body>


<div class="container">
<div class="col-sm-12 wowload fadeInUp">
<h2 class="sub-header">Download</h2>
<?php
  $konek = mysqli_connect("localhost","root","","hmi");

  $query = "SELECT * FROM upload ORDER BY id_upload DESC";
  $hasil = mysqli_query($konek, $query);

  while ($r = mysqli_fetch_array($hasil)){
    echo "Nama File : <b>$r[nama_file]</b> <br>";
    echo "Deskripsi : $r[deskripsi] <br>";
    echo "<a href=\"konten/simpan.php?file=$r[nama_file]\">Download File</a><hr><br>";
  }
?>