<?php
  if(!defined("INDEX")) die("---");
?>  
        <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyAlUnGH61TR6H6KnxsvfHT4zqeBBDEecMs"></script>
 
        <div id="map" style="width: 700px; height: 500px;"></div> 
 
        <script type="text/javascript">
              
//              menentukan koordinat titik tengah peta
              var myLatlng = new google.maps.LatLng(-0.5360785,117.1238037);
 
//              pengaturan zoom dan titik tengah peta
              var myOptions = {
                  zoom: 13,
                  center: myLatlng
              };
              
//              menampilkan output pada element
              var map = new google.maps.Map(document.getElementById("map"), myOptions);
              
//              menambahkan marker
              var marker = new google.maps.Marker({
                   position: myLatlng,
                   map: map,
                   title:"Politeknik Pertanian Negeri Samarinda"
              });
        </script> 
