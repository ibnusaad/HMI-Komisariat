<link rel="stylesheet" type="text/css" href="plugin/validity/jquery.validity.css">
<script type="text/javascript" src="plugin/validity/jquery.validity.min.js"></script>
<script type="text/javascript">
	$(function(){
		$('#formkontak').validity(function(){
			$('#nama')
					.require(' Nama tidak boleh kosong!');
			$('#email')
					.require(' Email tidak boleh kosong!')
					.match('email',' Email tidak valid!');
			$('#pesan')
					.require(' Pesan tidak boleh kosong');			
		});
	});
</script>
<?php
	if(!defined("INDEX")) die("---");	
?>


<div class="container">
<div class="col-sm-12 wowload fadeInUp">
<h1 class="title">Kontak</h1>
<form method="post" action="?tampil=kontak_proses" id="formkontak" class="form-horizontal well">
	<div class="form-group">
		<label for="nama" class="control-label col-md-2">Nama</label>
		<div class="col-md-10">
			<input type="text" name="nama" id="nama" class="form-control">
		</div>
	</div>
	<div class="form-group">
		<label for="email" class="control-label col-md-2">Email</label>
		<div class="col-md-10">
			<input type="text" name="email" id="email" class="form-control">
		</div>
	</div>
	<div class="form-group">
		<label for="pesan" class="control-label col-md-2">Pesan</label>
		<div class="col-md-10">
			<textarea type="text" name="pesan" id="pesan" rows="8" class="form-control"></textarea>
		</div>
	</div>
	<div class="form-group">
		<div class="col-md-10 col-md-offset-2">
			<input type="submit" value="Kirim Pesan" class="btn btn-success">
		</div>
	</div>
</form>