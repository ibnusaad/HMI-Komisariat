<!-- banner -->
<div class="col-sm-12 wowload fadeInUp">
<div class="banner">           
    <img src="images/photos/b.png"  class="img-responsive" alt="slide">
    <div class="welcome-message">
        <div class="wrap-info">
           
            <a href="#information" class="arrow-nav scroll wowload fadeInDownBig"><i class="fa fa-angle-down"></i></a>
        </div>
    </div>
</div>
<!-- banner--><br><br><br><br>