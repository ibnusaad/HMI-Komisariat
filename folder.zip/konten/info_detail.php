<?php
if(!defined("INDEX")) die ("---");

mysql_query("update Informasi set hits=hits+1
	where id_info='$_GET[id]'");

$Informasi = mysql_query("select * from Informasi where id_info='$_GET[id]'");
$data=mysql_fetch_array($Informasi);
$isi = $data['isi'];
?>

<div class="Informasi">
<h2 class="judul"><?php echo $data['judul']; ?></h2>
<p>
<?php if($data['gambar']!="") ?> <img src="gambar/informasi/<?php echo $data['gambar']; ?>" class="gambar-informasi" width="350">
<?php echo $isi; ?>
</p>
</div>