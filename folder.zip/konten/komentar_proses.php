<?php
	if(!defined("INDEX")) die("---");
	
	$nama	= $_POST['nama'];
	$email	= $_POST['email'];
	$komentar	= $_POST['komentar'];
	
	$subjek	= "Komentar dari pengunjung website";
	$dari	= "pemilik.website@gmail.com";
	$tgl	= date('Ymd');
	
	//mail($email,$subjek,$pesan,$dari);
	
	mysql_query("insert into komentar set nama='$nama', email='$email', subjek='$subjek', komentar='$komentar', tanggal='$tgl'") or die(mysql_error());
	
	echo"Komentar anda akan di saring terebih dahulu";
	echo"<meta http-equiv='refresh' content='1; url=?tampil=artikel_detail&id=$_POST[id]'>";
?>