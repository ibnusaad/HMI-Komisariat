<?php
$nama_gambar 	= $_FILES['gambar']['name'];
$lokasi_gambar = $_FILES['gambar']['tmp_name'];
$tipe_gambar	= $_FILES['gambar']['type'];

$tanggal	= date('Ymd');
$isi = addslashes($_POST['isi']);

if ($lokasi_gambar==""){
	mysql_query("UPDATE informasi SET 
judul = '$_POST[judul]',
isi 	='$isi'
where id_info='$_POST[id]'") or die (mysql_error());
} else {
	$data=mysql_fetch_array(mysql_query ("select * from informasi where id_info='$_POST[id]'"));

	if($data['gambar'] !="")
		unlink("../gambar/informasi/$data[gambar]");

	move_uploaded_file($lokasi_gambar,"../gambar/informasi/$nama_gambar");


	mysql_query("UPDATE informasi set 
judul	= '$_POST[judul]',
isi 	= '$isi',
gambar 	= '$nama_gambar'
where id_info='$_POST[id]'") or die (mysql_error());
		
}

echo "Data telah diedit";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=info'>";
?>