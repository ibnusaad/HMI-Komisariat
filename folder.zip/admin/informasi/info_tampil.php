<h2 class="sub-header">Data Informasi</h2>
<a href="?tampil=info_tambah" class="btn btn-primary"> Tambah Informasi </a><br><br>

<table width="100%" cellspacing="0" class="data" border="1">
<table class="table table-striped">
<tr>
<th>No</th>
<th>Judul informasi</th>
<th>Tanggal</th>
<th>Aksi</th>
</tr>

<?php
$no=1;
$tampil = mysql_query("SELECT * FROM informasi order by id_info desc") or die (mysql_error());
while ($data=mysql_fetch_array($tampil)){
	?>

	<tr>
	<td> <?php echo $no; ?> </td>
	<td> <?php echo $data['judul']; ?> </td>
	<td> <?php echo $data['tanggal']; ?> </td>
	<td>
	<a href="?tampil=info_edit&id=
		<?php echo $data['id_info']; ?>" class="btn btn-primary btn-sm"> Edit </a> |
	<a href="?tampil=info_hapus&id=
		<?php echo $data['id_info']; ?>" class="btn btn-danger btn-sm"> Hapus </a> 
		</td>
		</tr>
		<?php
		$no++;
}
?>
</table>