<?php
mysql_query("delete from komentar where id_komentar='$_GET[id]'") or die (mysql_error());
echo "Data telah dihapus";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=komentar'>";
?>