<?php
mysql_query("INSERT INTO komentar where id_artikel='setuju'");

echo "Komentar telah disetujui";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=komentar'>";
?>