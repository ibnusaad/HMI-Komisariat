<html>
<title>Form Upload</title>
<body>

<h2 class="sub-header">Data Upload</h2>
<form enctype="multipart/form-data" method="POST" action="?tampil=hasil_upload">
file yang di upload : <input type="file" name="fupload"><br>
Deskripsi File :<br>
<textarea name="deskripsi" rows="8" cols="40"></textarea><br>
<input type="submit" value="upload">
</form> 