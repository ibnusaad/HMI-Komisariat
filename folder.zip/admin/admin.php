<?php
	session_start();
	
	if(!empty($_SESSION['username'])and !empty($_SESSION['username'])){
		include("../lib/koneksi.php");
		define("INDEX",true);
?>

<html>
<head>
<meta charset="utf-8">
<link rel="shortcut icon" href="../img/favicon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $_SESSION['profesi'];?></title>

<link href="../cssadmin/bootstrap.min.css" rel="stylesheet">
<link href="../cssadmin/datepicker3.css" rel="stylesheet">
<link href="../cssadmin/styles.css" rel="stylesheet">

<!--Icons-->
<script src="../jsadmin/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>

	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
					</li>
				</ul>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
		<?php include("menu.php"); ?>

	</div><!--/.sidebar-->

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main"><br><br>	
		
			<?php include("konten.php"); ?>
	</div>
		

		
			

	<script src="../jsadmin/jquery-1.11.1.min.js"></script>
	<script src="../jsadmin/bootstrap.min.js"></script>
	<script src="../jsadmin/chart.min.js"></script>
	<script src="../jsadmin/chart-data.js"></script>
	<script src="../jsadmin/easypiechart.js"></script>
	<script src="../jsadmin/easypiechart-data.js"></script>
	<script src="../jsadmin/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>
</html>
<?php
	}else{
		echo"Dilarang membuka halaman ini!";
		echo"<meta http-equiv='refresh' content='1; url=index.php'>";
	}
?>