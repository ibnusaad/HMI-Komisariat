
<html><head>
<script type="text/javascript" href="../js/bootstrap.js" /></script>
<script type="text/javascript" href="../js/bootstrap.min.js" /></script>
<script type="text/javascript" href="../bahanbaku/js/jquery-ui.js" /></script>
<link rel="stylesheet" type="text/css" href="../css/utama.css">
<link rel="stylesheet" type="text/css" href="../css/format_form.css" />
<link rel="shortcut icon" href="../img/favicon.png" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
</head>

<body>

<div align="center" id="container">
<div class = "animate1 bounceInLeft" align="center">
<hr />
</div>

<form method="post" class="form-horizontal" id="form_login" action="ceklogin.php">
<table title="Log In Logsheet" class="table table-responsive animate4 bounceInRight">
<tr>
<td colspan="2"align="center"><h2 class="text-info"><span class="glyphicon glyphicon-book"></span> Login Log Sheet</h2></td>
</tr>
<tr>
	<td colspan="2"><input type="text" class="form-control form-control-static" placeholder="Username" name="username" maxlenght="16" required="required"/></td>
	</tr>
	<tr>
	 <td colspan="2"><input type="password" class="form-control" placeholder="Password" name="password" maxlength="16" required="required"/></td>
	 </tr>
	 <tr>
	 	<td align="center" width="50%"> <input type="submit" value="Login" class="btn btn-block btn-info" name="login"/></td>
	 	</tr>

	 	</table>
	 	</form>
	 </div>
	 	</body>
	 	</html>