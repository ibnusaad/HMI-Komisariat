<?php
if(isset ($_GET['tampil'])) $tampil = $_GET ['tampil'];
else $tampil = "beranda";

if($tampil == "beranda")	include ("beranda.php");
elseif($tampil == "keluar")	include ("keluar.php");

elseif($tampil == "menu")	include ("menu/menu_tampil.php");
elseif($tampil == "menu_tambah")	include ("menu/menu_tambah.php");
elseif($tampil == "menu_tambahproses")	include ("menu/menu_tambahproses.php");
elseif($tampil == "menu_edit")	include ("menu/menu_edit.php");
elseif($tampil == "menu_editproses")	include ("menu/menu_editproses.php");
elseif($tampil == "menu_hapus")	include ("menu/menu_hapus.php");

elseif($tampil == "submenu")	include ("submenu/submenu_tampil.php");
elseif($tampil == "submenu_tambah")	include ("submenu/submenu_tambah.php");
elseif($tampil == "submenu_tambahproses")	include ("submenu/submenu_tambahproses.php");
elseif($tampil == "submenu_edit")	include ("submenu/submenu_edit.php");
elseif($tampil == "submenu_editproses")	include ("submenu/submenu_editproses.php");
elseif($tampil == "submenu_hapus")	include ("submenu/submenu_hapus.php");

elseif($tampil == "halaman")	include ("halaman/halaman_tampil.php");
elseif($tampil == "halaman_tambah")	include ("halaman/halaman_tambah.php");
elseif($tampil == "halaman_tambahproses")	include ("halaman/halaman_tambahproses.php");
elseif($tampil == "halaman_edit")	include ("halaman/halaman_edit.php");
elseif($tampil == "halaman_editproses")	include ("halaman/halaman_editproses.php");
elseif($tampil == "halaman_hapus")	include ("halaman/halaman_hapus.php");

elseif($tampil == "artikel")	include ("artikel/artikel_tampil.php");
elseif($tampil == "artikel_tambah")	include ("artikel/artikel_tambah.php");
elseif($tampil == "artikel_tambahproses")	include ("artikel/artikel_tambahproses.php");
elseif($tampil == "artikel_edit")	include ("artikel/artikel_edit.php");
elseif($tampil == "artikel_editproses")	include ("artikel/artikel_editproses.php");
elseif($tampil == "artikel_hapus")	include ("artikel/artikel_hapus.php");

elseif($tampil == "islam")	include ("islam/islam_tampil.php");
elseif($tampil == "islam_tambah")	include ("islam/islam_tambah.php");
elseif($tampil == "islam_tambahproses")	include ("islam/islam_tambahproses.php");
elseif($tampil == "islam_edit")	include ("islam/islam_edit.php");
elseif($tampil == "islam_editproses")	include ("islam/islam_editproses.php");
elseif($tampil == "islam_hapus")	include ("islam/islam_hapus.php");

elseif($tampil == "info")	include ("informasi/info_tampil.php");
elseif($tampil == "info_tambah")	include ("informasi/info_tambah.php");
elseif($tampil == "info_tambahproses")	include ("informasi/info_tambahproses.php");
elseif($tampil == "info_edit")	include ("informasi/info_edit.php");
elseif($tampil == "info_editproses")	include ("informasi/info_editproses.php");
elseif($tampil == "info_hapus")	include ("informasi/info_hapus.php");

elseif($tampil == "ilmu")	include ("ilmu/ilmu_tampil.php");
elseif($tampil == "ilmu_tambah")	include ("ilmu/ilmu_tambah.php");
elseif($tampil == "ilmu_tambahproses")	include ("ilmu/ilmu_tambahproses.php");
elseif($tampil == "ilmu_edit")	include ("ilmu/ilmu_edit.php");
elseif($tampil == "ilmu_editproses")	include ("ilmu/ilmu_editproses.php");
elseif($tampil == "ilmu_hapus")	include ("ilmu/ilmu_hapus.php");


elseif($tampil == "galeri")	include ("galeri/galeri_tampil.php");
elseif($tampil == "galeri_tambah")	include ("galeri/galeri_tambah.php");
elseif($tampil == "galeri_tambahproses")	include ("galeri/galeri_tambahproses.php");
elseif($tampil == "galeri_edit")	include ("galeri/galeri_edit.php");
elseif($tampil == "galeri_editproses")	include ("galeri/galeri_editproses.php");
elseif($tampil == "galeri_hapus")	include ("galeri/galeri_hapus.php");

	elseif( $tampil == "upload" )				include("upload/upload.php");
	elseif( $tampil == "hasil_upload" )			include("upload/hasil_upload.php");
	elseif( $tampil == "download" )				include("upload/download.php");
	elseif( $tampil == "simpan" )				include("upload/simpan.php");

elseif($tampil == "pesan")	include ("pesan/pesan_tampil.php");
elseif($tampil == "pesan_balas")	include ("pesan/pesan_balas.php");
elseif($tampil == "pesan_balasproses")	include ("pesan/pesan_balasproses.php");
elseif($tampil == "pesan_hapus")	include ("pesan/pesan_hapus.php");

elseif($tampil == "komentar")	include ("komentar/komentar_tampil.php");
elseif($tampil == "komentar_show")	include ("komentar/komentar_show.php");
elseif($tampil == "komentar_hapus")	include ("komentar/komentar_hapus.php");
elseif($tampil == "komentar_setuju")	include ("komentar/komentar_setuju.php");
elseif($tampil == "komentar_proses_admin")	include ("komentar/komentar_proses_admin.php");

elseif($tampil == "user_edit")	include ("user/user_edit.php");
elseif($tampil == "user_editproses")	include ("user/user_editproses.php");

elseif($tampil == "bagan")	include ("SO/bagan.html");
elseif($tampil == "maps")	include ("maps/maps.php");




else echo"konten tidak ada";
?>
