<h2 class="sub-header">Data Opini</h2>
<a href="?tampil=ilmu_tambah" class="btn btn-primary"> Tambah Ilmu </a><br><br>

<table width="100%" cellspacing="0" class="data" border="1">
<table class="table table-striped">
<tr>
<th>No</th>
<th>Judul</th>
<th>Tanggal</th>
<th>Aksi</th>
</tr>

<?php
$no=1;
$tampil = mysql_query("SELECT * FROM ilmu order by id_ilmu desc") or die (mysql_error());
while ($data=mysql_fetch_array($tampil)){
	?>

	<tr>
	<td> <?php echo $no; ?> </td>
	<td> <?php echo $data['judul']; ?> </td>
	<td> <?php echo $data['tanggal']; ?> </td>
	<td>
	<a href="?tampil=ilmu_edit&id=
		<?php echo $data['id_ilmu']; ?>" class="btn btn-primary btn-sm"> Edit </a> |
	<a href="?tampil=ilmu_hapus&id=
		<?php echo $data['id_ilmu']; ?>" class="btn btn-danger btn-sm"> Hapus </a> 
		</td>
		</tr>
		<?php
		$no++;
}
?>
</table>