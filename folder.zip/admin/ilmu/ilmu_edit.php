<?php
$tampil = mysql_query("SELECT * FROM ilmu where id_ilmu='$_GET[id]'") or die(mysql_error());
$data = mysql_fetch_array($tampil);
?>

<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">

<h2 class="sub-header">Edit Opini</h2>

<form name="edit" method="post" action="?tampil=ilmu_editproses"
 enctype="multipart/form-data" class="form-horizontal">
<input type="hidden" name="id"
value="<?php echo $data['id_ilmu']; ?>">

<div class="form-group">
<label class="label-control col-md-2">Judul</label>
<div class="col-md-4">
<input type="text" class="form-control" name="judul" size="50" value="<?php echo $data['judul']; ?>">
</div></div>

<div class="form-group">
<label class="label-control col-md-2">Gambar</label>
<div class="col-md-4">
<img src="../gambar/ilmu/
<?php echo $data['gambar']; ?>" width="100"> <br>
<input type="file" class="form-control" name="gambar">
</div>
</div>

<div class="form-group">
<label class="label-control col-md-2">Isi</label>
<div class="col-md-8">
<textarea class="ckeditor" name="isi" id="ckedtor">
<?php echo $data['isi']; ?></textarea>
</div>
</div>

<div class="form-group">
<label class="label-control col-md-2"></label>
<div class="col-md-2">
<input type="submit" name="edit" value="Edit" class="btn btn-primary">
</div>
</div>

</form>