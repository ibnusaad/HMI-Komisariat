<?php
$data=mysql_fetch_array(mysql_query("select * from ilmu where id_ilmu='$_GET[id]'"));

if($data['gambar'] !="") unlink("gambar/ilmu/$data[gambar]");
mysql_query("delete from ilmu where id_ilmu='$_GET[id]'") or die (mysql_error());

echo "Data telah dihapus";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=ilmu'>";
?>