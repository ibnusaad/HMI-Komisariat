<?php
$data=mysql_fetch_array(mysql_query("select * from islam where id_islam='$_GET[id]'"));

if($data['gambar'] !="") unlink("../gambar/islam/$data[gambar]");
mysql_query("delete from islam where id_islam='$_GET[id]'") or die (mysql_error());

echo "Data telah dihapus";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=islam'>";
?>