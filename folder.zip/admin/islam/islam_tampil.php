<h2 class="sub-header">Data Islam</h2>
<a href="?tampil=islam_tambah" class="btn btn-primary"> Tambah </a><br><br>

<table width="100%" cellspacing="0" class="data" border="1">
<table class="table table-striped">
<tr>
<th>No</th>
<th>Judul </th>
<th>Tanggal</th>
<th>Aksi</th>
</tr>

<?php
$no=1;
$tampil = mysql_query("SELECT * FROM islam order by id_islam desc") or die (mysql_error());
while ($data=mysql_fetch_array($tampil)){
	?>

	<tr>
	<td> <?php echo $no; ?> </td>
	<td> <?php echo $data['judul']; ?> </td>
	<td> <?php echo $data['tanggal']; ?> </td>
	<td>
	<a href="?tampil=islam_edit&id=
		<?php echo $data['id_islam']; ?>" class="btn btn-primary btn-sm"> Edit </a> |
	<a href="?tampil=islam_hapus&id=
		<?php echo $data['id_islam']; ?>" class="btn btn-danger btn-sm"> Hapus </a> 
		</td>
		</tr>
		<?php
		$no++;
}
?>
</table>